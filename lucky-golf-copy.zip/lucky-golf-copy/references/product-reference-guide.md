
LUCKY GOLF — PRODUCT REFERENCE GUIDE

*Version 1.8 · Product facts and specs.

This is a spec sheet. It carries the factual attributes of every product Lucky sells — materials, construction, face treatments, lofts, dimensions, weights, prices. Nothing else. When copy needs a fact, it comes from here.

Voice, positioning, language rules, and CTAs live in a separate document — Lucky Golf — Product Language Rules. Voice and tone live in How We Write. Vocabulary lives in the Golf-Culture Reference.


The line
Lucky Golf currently sells across four categories: wedges, putters, hybrids, and apparel. A driver (LGD02) is in development and listed below; it is not yet on sale.


Wedges
LGW01 Carver
Category: wedge
Head material: 1020 forged carbon steel
Face: CNC-milled grooves, micro-grooved face, sandblasted face (combine into a dual-texture face)
Grind: K Grind
Available lofts: 50°, 52°, 54°, 56°, 58°, 60° (six lofts, all in production)
Finish: gold
Shaft: stock shaft
Grip: stock grip
Hand: right-hand and left-hand
Headcover: not included
Price: $99
LGW02 Carver — Gold
Category: wedge
Head material: 1020 forged carbon steel
Face: CNC-milled grooves, micro-grooved face, sandblasted face (combine into a dual-texture face)
Grind: S Grind
Available lofts: 52°, 56°, 60° (three lofts currently in production; 50°, 54°, 58° are in production and will bring the lineup to six)
Finish: gold
Shaft: stock shaft
Grip: stock grip
Hand: right-hand and left-hand
Headcover: not included
Price: $99 (live store, checked 2026-09-23; sold as "Carver 02 Gold")
LGW02 Carver — Black
Category: wedge
Head material: 1020 forged carbon steel
Face: CNC-milled grooves, micro-grooved face, sandblasted face (combine into a dual-texture face)
Grind: K Grind
Available lofts: 50°, 52°, 54°, 56°, 58°, 60° (six lofts, all in production)
Finish: blacked-out with gold accents on the clover, wordmark, loft stamp, and forged stamp
Shaft: stock shaft
Grip: stock grip
Hand: right-hand and left-hand
Headcover: not included
Price: $109

Platform note: LGW02 Black shares its underlying construction and manufacturer specs with the LGW01 platform (K Grind, LGW01 lies and bounces, six-loft lineup). The "LGW02" name signals product tier and pricing — it does not indicate a shared platform with LGW02 Gold. LGW02 Gold and LGW02 Black have different grinds and different dimensional specs despite sharing the LGW02 family name.


Putters
LGP01 Eclipse Blade
Formerly: Tracer Blade (renamed by Cole 2026-09-23; the live store still says Tracer until the switch, planned alongside the Havoc launch)
Category: putter
Head shape: blade
Construction: fully CNC-milled
Material: 431 stainless steel
Available loft: 3.5°
Available length: 35"
Finish: gold
Shaft: stock shaft
Grip: stock grip
Hand: right-hand only (currently)
Headcover: not included
Price: $199
LGP02 Eclipse Mallet
Formerly: Tracer Mallet (renamed 2026-09-23, same timing)
Category: putter
Head shape: mallet
Construction: fully CNC-milled
Material: 304 stainless steel
Available loft: 3.5°
Available length: 35"
Finish: gold
Shaft: stock shaft
Grip: stock grip
Hand: right-hand and left-hand
Headcover: not included
Price: $229


Hybrids
LGH01 Stryker
Category: hybrid
Head material: titanium
Face technology: Flex Channel face
Sole technology: Glide Sole
Available loft: 19°
Available length: 40.5"
Finish: face in brushed satin gold; sole in polished mirror gold; crown in gloss black with a gold starburst effect emanating from the center and fading to black at the edges; gold ferrule detail at the hosel; carries the Lucky clover mark on the crown
Shaft: Stiff (S) flex
Grip: stock grip
Hand: right-hand and left-hand
Headcover: not included
Price: $209


Drivers
Added 2026-09-16 from the Wenst spec emails and Tina Wu's replies of 2026-09-16. Not yet on sale. Head specs and shaft specs are listed separately because each shaft has its own profile.

LGD02 Driver
Name: Havoc (chosen by Cole 2026-09-23; trademark search still to do)
Category: driver
Status: not yet on sale
Price: not set

Head
Body material: 6-4 titanium, cast
Face material: SP700 titanium, variable thickness (thicker in the centre, thinner toward the perimeter)
Head size: 460cc
Head weight: 204g
Loft: 10.5°
Lie: 58°
Face angle: square (0°)
Bulge and roll: 12" / 12" (radius)
Hosel: adjustable adapter, 8 settings; changing the setting changes loft, lie and face angle together. Loft range and compatibility with other brands' sleeves: to confirm (the Wenst engineer is sending the settings chart)
Weighting: one 9g back weight and two 3g side screws (toe and heel), all interchangeable using the included torque wrench. The heavier weight moved toward the heel biases a draw; toward the toe, a fade.
Finish: gold, matte
Branding: "Lucky" filled in black on the sole
USGA: not on the conforming driver head list; the head has not been submitted for testing

Build
Assembled length: 45"
Swing weight: D2
Grip: unbranded, the factory's own mould, black rubber, 0.58" core

Shaft: Wenst (stock)
Flexes offered: Stiff. Regular is available to order from Wenst.
Stiff: 260 CPM and 3.7 torque (measured at 45" uncut), mid kick point, approximately 65g
Regular: specs to confirm

Shaft: KBS PGW CB 60 (upgrade)
Finish: black
Profile: low launch, low spin
Flexes: Stiff, Extra Stiff
Stiff (60 S BLK): 64g, 4.6 torque, tip flex 95, 4" parallel tip trim
Extra Stiff (60 X BLK): specs to confirm
Kick point: to confirm (requested from KBS)
Upgrade price: not set

In the box: white headcover, black torque wrench, driver box
Hand: not specified

Internal only, never in copy: production heads measure a CT of about 250, which is inside the USGA tolerance. The head is still not on the conforming list, so no copy may say "USGA conforming", "legal" or "tournament legal" until it is.

Note: LGD01 is the code of the earlier, discontinued $299 driver. Do not reuse it and do not carry its copy over.


Apparel
The Classic Polo
Category: polo
Fabric: 88% polyester, 12% spandex
Fit: athletic fit
Collar: classic collar
Sizing: S–3XL
Technical features: moisture-wicking, UPF 50+, four-way stretch, wrinkle-resistant, easy to clean
Colorways: rotating — not tracked here
Price: $67
Care: machine wash cold, tumble dry low (from the live product page, 2026-09-24)
Size chart (inches; from the live size guide, 2026-09-24). Chest is measured flat, pit to pit.
  S: length 28.3, chest 20.5, shoulder 17.7
  M: length 29.1, chest 21.7, shoulder 18.5
  L: length 29.9, chest 22.8, shoulder 19.3
  XL: length 30.7, chest 24.0, shoulder 20.1
  XXL: length 31.5, chest 25.2, shoulder 20.9
  3XL: length 32.3, chest 26.4, shoulder 21.7
Model sizing: none. Current polo photos are product shots with no model.
The Blade Polo
Category: polo
Fabric: 88% polyester, 12% spandex
Fit: athletic fit
Collar: blade collar
Sizing: S–3XL
Technical features: moisture-wicking, UPF 50+, four-way stretch, wrinkle-resistant, easy to clean
Colorways: rotating — not tracked here
Price: $67


Gloves
Lucky Tour Glove
Category: glove
Material: cabretta leather (live product page, 2026-09-25)
Detail: embroidered clover logo on the wrist strap
Hands: left and right (a left-hand glove is worn by right-handed golfers)
Sizes: S, M, L, XL
Price: $17.95
Reviews: 50 on Judge.me, 4.72 (2026-09-24)

Hats
Five-panel snapback
Category: hat
Style: five-panel snapback
Technical features: moisture-wicking sweatband, laser-cut ventilation
Colorways: rotating — not tracked here
Price: $29

Individual hat SKUs are not tracked in this document. SKUs and specific product names rotate. When copy needs a specific hat reference, confirm current lineup before writing.

Additional hat styles are planned for future release. When new styles launch, add them here.


Manufacturer specs
Per-product technical spec data from the manufacturer. Supports product page Details tabs, cart pages, and customer-facing surfaces that need precise numbers.

Source: manufacturer spec sheet dated 2025-11-13.
LGW01 Carver — spec table
Loft
Lie
Bounce
Head Weight
Length
50°
63°
8°
300g (±3g)
35.25" (±0.125")
52°
63°
8°
300g (±3g)
35.25" (±0.125")
54°
63°
12°
300g (±3g)
35.125" (±0.125")
56°
63°
12°
300g (±3g)
35.125" (±0.125")
58°
63°
10°
300g (±3g)
35" (±0.125")
60°
63°
10°
300g (±3g)
35" (±0.125")

Shaft: Regular (R) flex, mid kick point, 35" original length, 110g original weight Grip: 55g (±3g)
LGW02 Carver Black — spec table
LGW02 Black is built on the LGW01 platform. See the LGW01 spec table above for lie, bounce, head weight, and length across all six lofts. Grind is K Grind. Shaft, grip, and finish differ from LGW01 only in visual finish (blacked-out with gold accents).
LGW02 Carver Gold — spec table (three lofts in production)
Loft
Lie
Bounce
Head Weight
Length
52°
63.5°
10°
300g (±3g)
35.25" (±0.125")
56°
64°
12°
300g (±3g)
35.125" (±0.125")
60°
64°
12°
300g (±3g)
35" (±0.125")

Additional lofts (50°, 54°, 58°) are in production. Manufacturer specs will be added here once released.

Shaft: Regular (R) flex, mid kick point, 35" original length, 110g original weight Grip: 57g (±3g)
LGH01 Stryker Hybrid — spec table
Loft
Lie
Head Weight
Length
19°
59°
235g (±3g)
40.5"

Shaft: Stiff (S) flex, mid kick point, 40" original length, 68g original weight Grip: 58g (±3g)
LGP01 Eclipse Blade Putter — spec table
Loft
Lie
Head Weight
Length
3.5°
72°
385g (±3g)
35"

Shaft: Regular (R) flex, mid kick point, 35" original length, 110g original weight Grip: 75g (±3g)
LGP02 Eclipse Mallet Putter — spec table
Loft
Lie
Head Weight
Length
3.5°
72°
365g (±3g)
35"

Shaft: Regular (R) flex, mid kick point, 35" original length, 110g original weight Grip: 63g (±3g)


What's not in this document
This is a spec sheet. It does not carry:

Voice, tone, or register — see How We Write
Product-specific language rules, positioning, CTAs, or tax phrases — see Product Language Rules
Spec-to-benefit translations (what a spec means for the golfer) — see Spec-to-Benefit Translation Guide
Golf-culture vocabulary — see Golf-Culture Reference
Format-specific writing guidance — see Format-Specific Guidance
Future or unreleased products — this document only carries products currently in market or in confirmed production


Return policy
Return policy applies across all Lucky Golf products. Customer-facing return policy is published on luckywedges.com. The below is captured here as the source of truth for copy that references return terms.
General return rules (all products)
Returns must be initiated within the applicable return window for the product category.
Refunds are issued only after the returned item is received and inspected.
Customers are responsible for return shipping costs.
Original shipping fees are non-refundable.
Items returned outside stated conditions may be subject to partial refunds or return denial.
Customized items are final sale and not eligible for return unless deemed defective.
How to start a return
Apparel and gear: through the Returns Portal or the instructions in the order confirmation.
Golf clubs: all club returns require approval before being sent back. Contact Customer Support through website chat or at support@luckygolf.com.
Golf clubs — 60-day return policy
All golf club returns require approval before return, require photo verification prior to approval, and are refunded only after physical inspection.

Putters: may be used during the 60-day period. To qualify for a refund, must be returned in brand-new condition with no face marks, sole wear, scratches, dents, chips, bag chatter, or grip wear. Modifications (regripping, bending, cutting, altering) are not permitted. Wear or damage may result in partial refund or return denial.

Wedges: only one wedge per set may be opened and tested, on a turf mat or other non-abrasive surface. Must be returned in brand-new condition with no groove wear, face marks, sole wear, or cosmetic or structural damage. All other wedges in the set must remain factory sealed. Significant use or damage may result in partial refund or return denial.

Irons: only the 7-iron may be removed from factory plastic and tested on a turf mat or non-abrasive surface. All other irons must remain factory sealed. Entire set must be returned in brand-new condition. Significant use or damage may result in partial refund or return denial.

Drivers, hybrids, and woods: must appear completely unused, with no visible signs of wear or damage and no modifications. Significant use or damage may result in partial refund or no refund depending on condition.
Apparel — 30-day return policy
Must be unworn, unwashed, and in original condition.
All original tags must be attached.
No visible wear or damage: no makeup or deodorant stains, odors, pet hair, stretching, or laundering.
Items returned without tags will have a $7 fee deducted from the refund.
Returns requested after 30 days of delivery will not be accepted.
Gear and accessories — 30-day return policy
Must be returned in unused condition.
Items showing wear, damage, or use are not eligible for return.
Defective items may be eligible for replacement or refund upon inspection.
Customized items
All customized products are final sale and not eligible for return or refund unless deemed defective upon inspection.
Non-returnable conditions (all products)
Returns will not be accepted if the item shows visible wear or damage beyond stated conditions, has been modified, is outside the return window, is missing required approval or documentation, or is returned without authorization.


What needs verification before publishing v1.8
LGW02 Gold additional loft manufacturer specs (50°, 54°, 58°). Currently in production. Update the LGW02 Gold spec table once released.

Last updated: July 2026 · v1.8

v1.8 — locks in putter finishes (both LGP01 and LGP02 are gold). Corrects LGW02 Black spec entry to reflect that it is built on the LGW01 platform (K Grind, LGW01 lies and bounces, six-loft lineup) — the LGW02 name signals product tier and pricing, not shared platform with LGW02 Gold. Adds a Platform note under LGW02 Black clarifying this. Adds an LGW02 Black entry to the Manufacturer Specs section pointing at the LGW01 spec table. Down to one open item (LGW02 Gold additional loft specs). Return policy iron references retained as forward-looking language for future products.

v1.7 — locked in Stryker finish with detailed visual reference. Added full return policy content.

v1.6 — locked in prices, hand availability, headcover status across the line.

v1.5 — restructured as pure spec sheet.

